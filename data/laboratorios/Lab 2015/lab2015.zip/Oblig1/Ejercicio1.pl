%largo(+L,?N), siendo N el largo de la lista L.

largo([],0).  % largo de la lista vacia es 0
largo([H|T], X) :- largo(T, N), X is N+1.  % largo de una lista es 1 + largo de la cola de la lista.

---------------------------------------------------------------------------------------------------------

%todos_iguales(?L,?E), todos los elemento de la lista L son iguales a E.

todos_iguales([X],X). %si tiene un solo elemento.
todos_iguales([H|T], H):-todos_iguales(T, H). % si la cabeza cumple la igualdad, me fijo la cola.

---------------------------------------------------------------------------------------------------------

%fibonacci3_simple(+N,?F) F es Fibonacci3 sin acumuladores del numero N

fibonacci3_simple(0, 1).
fibonacci3_simple(1, 1).
fibonacci3_simple(2, 1).
fibonacci3_simple(X, F) :- X>0,X < 31, A is X-1, B is X-2, C is X-3,
                    fibonacci3_simple(A, F1), fibonacci3_simple(B, F2),
                    fibonacci3_simple(C, F3), F is F1+F2+F3.  % N debe ser un numero entre 0 y 30.
                                          % F se define como fib(N)= fib(N-1) + fib(N-2)+ fib(N-3)

---------------------------------------------------------------------------------------------------------

%fibonacci3(+N, ?F) F es Fibonacci3 utilizando acumuladores del numero N

fibonacci3(0,1).
fibonacci3(1,1).
fibonacci3(2,1).
fibonacci3(N,F):- fib1(N,1,1,1,F).  % F1, F2, F3 comienzan valiendo 1, corresponden a las clausulas base.
fib1(3,F1,F2,F3,F):- F is F1+F2+F3.
fib1(N,F1,F2,F3,F):- N>0,N<151,F4 is F1+F2+F3,  N1 is N-1, fib1(N1,F2,F3,F4,F).  % F1,F2,F3 son los acumuladores.


---------------------------------------------------------------------------------------------------------

%concatenacion(?L1, ?L2, ?L) % La lista L es la concatenacion de L1 y L2

concatenacion([], L, L). % Concatena la lista vacia con L2 da la lista L2
concatenacion([H|L1], L2, [H|L]):- concatenacion(L1, L2, L). % Pongo la cabeza de L1 en L y continuo con la cola.

---------------------------------------------------------------------------------------------------------

%sublista(?L, ?Sub) % Sub es una sublista de la lista L.

sufijo(S,L) :- append(_,S,L), S\=[].   %S es un sufijo de L.
prefijo(P,L) :- append(P,_,L).  %P es un sufijo de P
sublista(L,Sub) :- sufijo(S,L),prefijo(Sub,S).  % Una sublista de una lista L es simplemente los
                                                % prefijos de los sufijos de L


---------------------------------------------------------------------------------------------------------

% sin_elem(+L,?E, ?LSinE) LSinE es la lista L sin una ocurrencia de la lista L.

sin_elem([H|T], H, T). % Si encuentro la ocurrencia en la cabeza la saco.
sin_elem([H|T], X, [H|L]) :- sin_elem(T, X, L). % Si no encuentro E en la cabeza, busco en la cola.


---------------------------------------------------------------------------------------------------------

%rotacion(+L, ?R) La lista R es una rotacion de la lista L.

rotacion([H|T],X):-append(B,A,[H|T]),append(A,B,X), B\=[]. % Coloco la cabeza en el final de la lista.



