--------------------------------------------------------------------------------------------------------------------
% 2) RESOLUCION DE UN PUZLE


%FUNCIONES AUXILIARES 

% distinto(?A,?B). -> Verifica que sean distintos, en este caso: cabeza y otro cola. 
distinto(co,ca).
distinto(ca,co). 

%es_rotacion(+L, ?X) -> La lista X es una rotacion de la lista L. Es como la funcion rotacion de la parte 1, sirve para ver si una pieza es rotacion de otra. 
es_rotacion(L,X):-append(B,A,L), append(A,B,X), A\=[].

%sin_elem(+L, ?E, ?LSinE) -> LSinE es la lista L sin una ocurrencia del elemento E. Este predicado sirve para asignar las piezas a la solucion correspondiente para despues hacerle la rotacion adecuada, si es necesario.    
sin_elem([H|T], H, T).
sin_elem([H|T], X, [H|L]) :- sin_elem(T, X, L).

%FUNCION PRINCIPAL
%puzle(+Piezas, ?Sol) -> Sol es la solucion al puzzle especificado por Piezas. 
puzle([
[lado(P1L1A,P1L1B), lado(P1L2A,P1L2B), lado(P1L3A,P1L3B), lado(P1L4A,P1L4B)],
[lado(P2L1A,P2L1B), lado(P2L2A,P2L2B), lado(P2L3A,P2L3B), lado(P2L4A,P2L4B)],
[lado(P3L1A,P3L1B), lado(P3L2A,P3L2B), lado(P3L3A,P3L3B), lado(P3L4A,P3L4B)],
[lado(P4L1A,P4L1B), lado(P4L2A,P4L2B), lado(P4L3A,P4L3B), lado(P4L4A,P4L4B)],
[lado(P5L1A,P5L1B), lado(P5L2A,P5L2B), lado(P5L3A,P5L3B), lado(P5L4A,P5L4B)],
[lado(P6L1A,P6L1B), lado(P6L2A,P6L2B), lado(P6L3A,P6L3B), lado(P6L4A,P6L4B)],
[lado(P7L1A,P7L1B), lado(P7L2A,P7L2B), lado(P7L3A,P7L3B), lado(P7L4A,P7L4B)],
[lado(P8L1A,P8L1B), lado(P8L2A,P8L2B), lado(P8L3A,P8L3B), lado(P8L4A,P8L4B)],
[lado(P9L1A,P9L1B), lado(P9L2A,P9L2B), lado(P9L3A,P9L3B), lado(P9L4A,P9L4B)]
],
[
[lado(SP1L1A,SP1L1B), lado(SP1L2A,SP1L2B), lado(A1,A), lado(B1,B)],
[lado(A2,A), lado(SP2L2A,SP2L2B), lado(C1,C), lado(D1,D)],
[lado(C2,C), lado(SP3L2A,SP3L2B), lado(SP3L3A,SP3L3B), lado(E1,E)],
[lado(SP4L1A,SP4L1B), lado(B2,B), lado(F1,F), lado(G1,G)],
[lado(F2,F), lado(D2,D), lado(H1,H), lado(I1,I)],
[lado(H2,H), lado(E2,E), lado(SP6L3A,SP6L3B), lado(J1,J)],
[lado(SP7L1A,SP7L1B), lado(G2,G), lado(K1,K), lado(SP7L4A,SP7L4B)],
[lado(K2,K), lado(I2,I), lado(L1,L), lado(SP8L4A,SP8L4B)],
[lado(L2,L), lado(J2,J), lado(SP9L3A,SP9L3B), lado(SP9L4A,SP9L4B)]
]) :-

sin_elem([[lado(P1L1A,P1L1B), lado(P1L2A,P1L2B), lado(P1L3A,P1L3B), lado(P1L4A,P1L4B)], [lado(P2L1A,P2L1B), lado(P2L2A,P2L2B), lado(P2L3A,P2L3B), lado(P2L4A,P2L4B)], [lado(P3L1A,P3L1B), lado(P3L2A,P3L2B), lado(P3L3A,P3L3B), lado(P3L4A,P3L4B)], [lado(P4L1A,P4L1B), lado(P4L2A,P4L2B), lado(P4L3A,P4L3B), lado(P4L4A,P4L4B)], [lado(P5L1A,P5L1B), lado(P5L2A,P5L2B), lado(P5L3A,P5L3B), lado(P5L4A,P5L4B)], [lado(P6L1A,P6L1B), lado(P6L2A,P6L2B), lado(P6L3A,P6L3B), lado(P6L4A,P6L4B)], [lado(P7L1A,P7L1B), lado(P7L2A,P7L2B), lado(P7L3A,P7L3B), lado(P7L4A,P7L4B)], [lado(P8L1A,P8L1B), lado(P8L2A,P8L2B), lado(P8L3A,P8L3B), lado(P8L4A,P8L4B)], [lado(P9L1A,P9L1B), lado(P9L2A,P9L2B), lado(P9L3A,P9L3B), lado(P9L4A,P9L4B)]],P1,ListaSinP1),
sin_elem(ListaSinP1,P2,ListaSinP1P2),
sin_elem(ListaSinP1P2,P3,ListaSinP1P2P3),
sin_elem(ListaSinP1P2P3,P4,ListaSinP1P2P3P4),
sin_elem(ListaSinP1P2P3P4,P5,ListaSinP1P2P3P4P5),
sin_elem(ListaSinP1P2P3P4P5,P6,ListaSinP1P2P3P4P5P6),
sin_elem(ListaSinP1P2P3P4P5P6,P7,ListaSinP1P2P3P4P5P6P7),
sin_elem(ListaSinP1P2P3P4P5P6P7,P8,ListaSinP1P2P3P4P5P6P7P8),
sin_elem(ListaSinP1P2P3P4P5P6P7P8,P9,[]),

es_rotacion(P1,[lado(SP1L1A,SP1L1B), lado(SP1L2A,SP1L2B), lado(A1,A), lado(B1,B)]),
es_rotacion(P2,[lado(A2,A), lado(SP2L2A,SP2L2B), lado(C1,C), lado(D1,D)]),
es_rotacion(P3,[lado(C2,C), lado(SP3L2A,SP3L2B), lado(SP3L3A,SP3L3B), lado(E1,E)]),
es_rotacion(P4,[lado(SP4L1A,SP4L1B), lado(B2,B), lado(F1,F), lado(G1,G)]),
es_rotacion(P5,[lado(F2,F), lado(D2,D), lado(H1,H), lado(I1,I)]),
es_rotacion(P6,[lado(H2,H), lado(E2,E), lado(SP6L3A,SP6L3B), lado(J1,J)]), 
es_rotacion(P7,[lado(SP7L1A,SP7L1B), lado(G2,G), lado(K1,K), lado(SP7L4A,SP7L4B)]),
es_rotacion(P8,[lado(K2,K), lado(I2,I), lado(L1,L), lado(SP8L4A,SP8L4B)]),
es_rotacion(P9,[lado(L2,L), lado(J2,J), lado(SP9L3A,SP9L3B), lado(SP9L4A,SP9L4B)]),

distinto(A1, A2), 
distinto(B1, B2), 
distinto(C1,C2), 
distinto(D1,D2), 
distinto(E1,E2), 
distinto(F1,F2), 
distinto(G1,G2), 
distinto(H1,H2), 
distinto(J1,J2), 
distinto(K1,K2), 
distinto(L1,L2), 
distinto(I1,I2).
