% matriz(+I,+J,+E,?A) <- A es una matriz de M filas y N columnas. Cada celda debe tener el valor E.

matriz(_,0,_,[]). % Matriz con 0 columnas es vacio.
matriz(M,N,E,A) :- generarMatriz(0,M,N,E,A).
generarMatriz(X,X,_,_,[]).
generarMatriz(Ac,X,N,E,[Y|Ys]) :- generarFila(0,N,Y,E), Ac1 is Ac+1 , generarMatriz(Ac1,X,N,E,Ys). % Utilizado para ir generando las distintas filas
generarFila(X,X,[],_).
generarFila(Ac,X,[E|F],E) :- Ac1 is Ac +1 , generarFila(Ac1,X,F,E). %Genera una fila de la matriz con el valor E.

% ----------------------------------------------------------------------------------------------------------------------------------------------------------------
% valor_celda(+I, +J, +A, ?E)

rowN([H|_],1,H).
rowN([_|T],I,X) :-I1 is I-1, rowN(T,I1,X). % Si no es la fila buscada sigo con otra fila.
findR([H|T],1,H). % Si encuentro la posicion devuelvo la cabeza de la lista.
findR([H|T],N,X) :- N1 is N-1, findR(T,N1,X). % Si no es la posicion buscada sigo buscando en la cola.
valor_celda(I,J,A,E) :- rowN(A,I,F), findR(F, J, E). %Busco la fila y despues el elemento dentro de la fila.

% ----------------------------------------------------------------------------------------------------------------------------------------------------------------
%

%nuevo_valor_celda(+I, +J, +A1, +E, -A2)
nuevo_valor_col(X,X,[_|Ms],Val,[Val|Ms]).
nuevo_valor_col(Ac,X,[M|Ms],Val,[M|Rs]) :- Ac1 is Ac+1, nuevo_valor_col(Ac1,X,Ms,Val,Rs).

nuevo_valor_fil(X,X,J,[M|Ms],Val,[R|Ms]) :- nuevo_valor_col(1,J,M,Val,R).
nuevo_valor_fil(Ac,X,J,[M|Ms],Val,[M|R]) :- Ac1 is Ac+1 , nuevo_valor_fil(Ac1,X,J,Ms,Val,R).

nuevo_valor_celda(I,J,M1,Val,M2) :- nuevo_valor_fil(1,I,J,M1,Val,M2).


% ----------------------------------------------------------------------------------------------------------------------------------------------------------------
%

%columna(+M,+N,+A,+J,?C)

columna(M,N,A,J,C):- column(A,J,C).
column([],_,[]).
column([H|T], I, [R|X]):-rowN(H, I, R),column(T,I,X). %Agarra cada fila y saca el elemento buscado.
