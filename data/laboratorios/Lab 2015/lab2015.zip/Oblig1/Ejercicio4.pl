
% matriz_f(+I,+J,+E,?M) <- M es una matriz de I filas y J columnas. Cada celda debe tener el valor E.

matriz_f(I,J,E,M) :- matriz_f_ac(1,I,J,E,M).

% matriz_f_ac(+Ac,+I,+J,+E,?M) <- M es una matriz de I filas e J columnas. Cada celda debe tener el valor E, I>=Ac.

matriz_f_ac(I,I,J,E,M) :- functor(M,matrix,I), generarFila_f(1,J,E,Y), arg(I,M,Y).
matriz_f_ac(Ac,I,J,E,M) :- functor(M,matrix,I),generarFila_f(1,J,E,Y), arg(Ac,M,Y),Ac1 is Ac+1, matriz_f_ac(Ac1,I,J,E,M).

% generarFila_f(+Ac,+J,+Val,?Row) <-Row es la fila de largo X y valor Val en sus argumentos.
generarFila_f(X,X,E,Row) :- functor(Row,row,X), arg(X,Row,E).
generarFila_f(Ac,X,E,Row) :-functor(Row,row,X), arg(Ac,Row,E), Ac1 is Ac+1, generarFila_f(Ac1,X,E,Row).


valor_celda(I, J, M, E) :- arg(I, M, F), arg(J, F, E).

nuevo_valor_celda(I, J, A, E) :-arg(I, A, F),setarg(J, F, E).

%columna(+M,+N,+A,+J,?C)

%columna(M,N,A,J,C):- column(M,M,N,A,J,C).
%column(F,0,N,A,J,C):- functor(C,col,F).
%column(F,M,N,A,J,C):- M>0, M1 is M-1, column(F,M1,N,A,J,C),valor_celda(M,J,A,E), setarg(M,C,E).

columna_f(M, N, A, J, C) :- J<N+1, A=..[_|L], functor(C, col, M), columna_ff(0,M,L,J,C). 
columna_ff(M,M,[],J,C). 
columna_ff(M1, M, [H|T],J,C):-M1<M, M2 is M1+1, arg(J,H,Arg), arg(M2,C,Arg), columna_ff(M2,M,T,J,C). 
  

