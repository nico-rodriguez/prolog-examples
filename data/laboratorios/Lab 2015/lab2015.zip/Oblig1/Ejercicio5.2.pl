
% matriz_f(+M,+N,+E,?A) <- A es una matriz de M filas y N columnas. Cada celda debe tener el valor E.

matriz_f(M,N,E,A) :- matriz_f_ac(1,M,N,E,A).

% matriz_f_ac(+Ac,+M,+N,+E,?A) <- A es una matriz de M filas e N columnas. Cada celda debe tener el valor E.

matriz_f_ac(M,M,N,E,A) :- functor(A,matrix,M), generarFila_f(1,N,E,Y), arg(M,A,Y).
matriz_f_ac(Ac,M,N,E,A) :- functor(A,matrix,M),generarFila_f(1,N,E,Y), arg(Ac,A,Y),Ac1 is Ac+1, matriz_f_ac(Ac1,M,N,E,A).

% generarFila_f(+Ac,+N,+E,?Row) <-Row es la fila de largo X y valor E en sus argumentos.
generarFila_f(X,X,E,Row) :- functor(Row,row,X), arg(X,Row,E).
generarFila_f(Ac,X,E,Row) :-functor(Row,row,X), arg(Ac,Row,E), Ac1 is Ac+1, generarFila_f(Ac1,X,E,Row).

%------------------------------------------------------------------------------------------------------------

%nuevo_valor_celda_f(+M,+N,+A,+E) ← Cambia el contenido de la celda (M,N) de la matriz A por el valor E. A está representada en el formato definido para matriz_f.


nuevo_valor_celda(I, J, A, E) :-arg(I, A, F),setarg(J, F, E). %Agaro la fila y luego seteo el elemento.



% crearMatrizTT_f(+T,-M) <- M es una matriz TxT donde cada celda (I,J) contiene el valor (I+J)

crearMatrizTT_f(M,N,A) :- matriz_f(M,N,0,A), rellenarMatriz_f(1,1,M,N,A).

% rellenarMatriz_f(+I,+J,M,N,A) <- I,J son acumuladores que representan la celda actual, T es el tamaño de la matriz, M es la matriz
%								   que resulta de reempplazar los elementos (a,b) por el valor a+b.

rellenarMatriz_f(I,J,M,N,A):- I>M.
rellenarMatriz_f(I,J,M,N,A):- J>N, W is I+1, rellenarMatriz_f(W,1,M,N,A).
rellenarMatriz_f(I,J,M,N,A) :- J<N+1,Y is I+J, nuevo_valor_celda(I,J,A,Y), X is J+1, rellenarMatriz_f(I,X,M,N,A).



