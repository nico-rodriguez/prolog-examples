
% matriz(+I,+J,+Val,?M) <- M es una matriz de I filas y J columnas. Cada celda debe tener el valor Val.
matriz(_,0,_,[]).
matriz(I,J,Val,M) :- generarMatriz(0,I,J,Val,M).

% generarMatriz(+Ac,+I,+J,+Val,?M) <- M es la matriz de I filas de J columnas con valor Val en cada entrada, J>=Ac
generarMatriz(X,X,_,_,[]).
generarMatriz(Ac,X,J,Val,[Y|Ys]) :- generarFila(0,J,Y,Val), Ac1 is Ac+1 , generarMatriz(Ac1,X,J,Val,Ys).

% generarFila(Ac,LargoFila,Fila, Val) <- Fila es una lista de largo LargoFila con valor Val en vada entrada. LargoFila >=Ac
generarFila(X,X,[],_).
generarFila(Ac,X,[Val|F],Val) :- Ac1 is Ac +1 , generarFila(Ac1,X,F,Val).

%nuevo_valor_celda(+I, +J, +A1, +E, -A2)
nuevo_valor_col(X,X,[_|Ms],Val,[Val|Ms]).
nuevo_valor_col(Ac,X,[M|Ms],Val,[M|Rs]) :- Ac1 is Ac+1, nuevo_valor_col(Ac1,X,Ms,Val,Rs).

nuevo_valor_fil(X,X,J,[M|Ms],Val,[R|Ms]) :- nuevo_valor_col(1,J,M,Val,R).
nuevo_valor_fil(Ac,X,J,[M|Ms],Val,[M|R]) :- Ac1 is Ac+1 , nuevo_valor_fil(Ac1,X,J,Ms,Val,R).

nuevo_valor_celda(I,J,M1,Val,M2) :- nuevo_valor_fil(1,I,J,M1,Val,M2).



% crearMatrizTT_f(+T,-M) <- M es una matriz TxT donde cada celda (I,J) contiene el valor (I+J)

crearMatrizTT_f(M,N,M2) :- matriz(M,N,0,A), rellenarMatriz(1,1,M,N,A,M2).

% rellenarMatriz_f(+I,+J,M,N,A) <- I,J son acumuladores que representan la celda actual, T es el tamaño de la matriz, M es la matriz
%								   que resulta de reempplazar los elementos (a,b) por el valor a+b.

rellenarMatriz(I, J, M, N, M1, M4) :- I<M, J<N+1, X is I+J, nuevo_valor_celda(I, J, M1, X, M2), II is I+1, JJ is J+1, rellenarMatriz_f(I, JJ, M, N, M2, M3), rellenarMatriz(II, J, M, N, M3, M4). 
rellenarMatriz(M, J, M, N, M1, M3):- J<N, X is M+J, nuevo_valor_celda(M, J, M1, X, M2), JJ is J+1, rellenarMatriz_f(M, JJ, M, N, M2, M3).
rellenarMatriz(M, N, M, N, M1, M2):- X is M+N, nuevo_valor_celda(M, N, M1, X, M2).

rellenarMatriz_f(I, J, M, N, M1, M3) :- J<N, X is I+J, nuevo_valor_celda(I, J, M2, X, M3), JJ is J+1, rellenarMatriz_f(I, JJ, M, N, M1, M2).
rellenarMatriz_f(I, N, M, N, M1, M2) :- X is I+N, nuevo_valor_celda(I, N, M1, X, M2).


