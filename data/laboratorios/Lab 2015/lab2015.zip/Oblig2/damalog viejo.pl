evento(maquina, Y, fin_turno,Visual,M,Turno, _) :- 
      minimax_levels(U),
      minimax(M, Turno, Move , U),
      dibujar(Visual, Move), 
      distinto(Turno, Turno2), 
      loop(Y, maquina, Visual, Move, Turno2, _).

minimax(M, Turno, Move, U) :-
	minimax(M, Turno, BestMove, -10000, max, Prof).

minimax(M, Turno, BestMove, BestValue, MaxMin, 0):-
  evaluar(M, Turno, Val).

minimax(M, Turno, BestMove, BestValue, MaxMin, Prof):-
  es_fin_juego(M, _, Val).

minimax(M, Turno, BestMove, BestValue, MaxMin, Prof):-
  findall(M, ((between(1,8,X)), (between(1,8,Y)), write(X), write(Y), writeln(''), valor_celda_f(X, Y, M, E), ficha_correcta(Turno, E), validar_jugada(M, posicion(X,Y), T, E, L), hacer_jugada(M, L, E), writeln(''), writeln(M), writeln('')), MList),
  obtenerMejorMov(MList, Turno, BestMove, BestValue, MaxMin, Prof).



obtenerMejorMov([L], Turno, BestMove2, BestValue2, MaxMin, Prof) :-
	Prof1 is Prof-1, 
	cambiar(MaxMin, MaxMin1),
	minimax(L, Turno, BestMove2, BestValue2, MaxMin1, Prof1). 

obtenerMejorMov([L|T], Turno, BestMove, BestValue, MaxMin, Prof) :-
	obtenerMejorMov(T, Turno, BestMove1, BestValue1, MaxMin, Prof),
	Prof1 is Prof-1, 
	cambiar(MaxMin, MaxMin1),
	minimax(L, Turno, BestMove2, BestValue2, MaxMin1, Prof1),
	((MaxMin = max) 
		-> 
		es_max(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue),
		;
		es_min(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue),
	). 

es_max(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue) :-
	BestValue1 >= BestValue2, BestMove = BestMove1, BestValue = BestValue1. 
es_max(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue) :-
	BestValue1 < BestValue2, BestMove = BestMove2, BestValue = BestValue2.   

es_min(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue) :-
	BestValue1 >= BestValue2, BestMove = BestMove2, BestValue = BestValue2. 
es_min(BestMove1, BestValue1, BestMove2, BestValue2, BestMove, BestValue) :-
	BestValue1 < BestValue2, BestMove = BestMove1, BestValue = BestValue1.   