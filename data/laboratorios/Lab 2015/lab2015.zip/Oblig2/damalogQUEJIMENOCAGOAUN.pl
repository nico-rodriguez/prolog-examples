:- use_module(graficos).

%%%%%%%%%% FUNCIONES AUXILIARES %%%%%%%%%%%%%%%%%%%%%%%%%
traducir(0, fondo_negro).
traducir(1, comun_roja).
traducir(2, comun_negra).
traducir(3, dama_roja).
traducir(4, dama_negra).

distinto(rojas, negras). 
distinto(negras, rojas).

ficha_correcta(rojas, 1). 
ficha_correcta(rojas, 3). 
ficha_correcta(negras, 2). 
ficha_correcta(negras, 4). 

es_negra(2).  
es_negra(4).  
es_roja(1).  
es_roja(3).  

es_contraria(3,2). 
es_contraria(3,4). 
es_contraria(4,1). 
es_contraria(4,3). 

% minimax_levels(?Nivel). <- cantidad de niveles por defecto para el algoritmo minimax
minimax_levels(2).

% damalog(+JugadorRojas,+JugadorNegras) <- predicado principal, los jugadores pueden ser humano o maquina
damalog(X,Y) :-
    gr_crear(Visual, [
            boton('Fin turno',fin_turno),
            boton('Reiniciar',reiniciar),
            boton('Guardar',guardar),
            boton('Cargar',cargar),
            boton('Salir',salir)]), % salir puede ser por el boton o por el click en la ventana
    matriz_f(8,8,-1,M),
    dibujarInicial(Visual, M),
    loop(X, Y, Visual, M, negras, []),
    !,
    gr_destruir(Visual).

dibujarInicial(Visual, M):-
   nuevo_valor_celda_f(1,1,M,0),
   nuevo_valor_celda_f(1,3,M,0),
   nuevo_valor_celda_f(1,5,M,0),
   nuevo_valor_celda_f(1,7,M,1),
   nuevo_valor_celda_f(2,2,M,0),
   nuevo_valor_celda_f(2,4,M,0),
   nuevo_valor_celda_f(2,6,M,0),
   nuevo_valor_celda_f(2,8,M,2),
   nuevo_valor_celda_f(3,1,M,0),
   nuevo_valor_celda_f(3,3,M,0),
   nuevo_valor_celda_f(3,5,M,1),
   nuevo_valor_celda_f(3,7,M,2),
   nuevo_valor_celda_f(4,2,M,0),
   nuevo_valor_celda_f(4,4,M,0),
   nuevo_valor_celda_f(4,6,M,1),
   nuevo_valor_celda_f(4,8,M,0),
   nuevo_valor_celda_f(5,1,M,0),
   nuevo_valor_celda_f(5,3,M,0),
   nuevo_valor_celda_f(5,5,M,0),
   nuevo_valor_celda_f(5,7,M,2),
   nuevo_valor_celda_f(6,2,M,0),
   nuevo_valor_celda_f(6,4,M,0),
   nuevo_valor_celda_f(6,6,M,0),
   nuevo_valor_celda_f(6,8,M,0),
   nuevo_valor_celda_f(7,1,M,2),
   nuevo_valor_celda_f(7,3,M,2),
   nuevo_valor_celda_f(7,5,M,0),
   nuevo_valor_celda_f(7,7,M,0),
   nuevo_valor_celda_f(8,2,M,2),
   nuevo_valor_celda_f(8,4,M,2),
   nuevo_valor_celda_f(8,6,M,0),
   nuevo_valor_celda_f(8,8,M,2), 
   dibujar(Visual, M).


dibujar(Visual,M) :-
    gr_tablero(Visual),
    valor_celda_f(1, 1, M, E1),   traducir(E1, Tipo1),    gr_ficha(Visual, 1, 1, Tipo1),
    valor_celda_f(1, 3, M, E2),   traducir(E2, Tipo2),    gr_ficha(Visual, 1, 3, Tipo2),
    valor_celda_f(1, 5, M, E3),   traducir(E3, Tipo3),    gr_ficha(Visual, 1, 5, Tipo3),
    valor_celda_f(1, 7, M, E4),   traducir(E4, Tipo4),    gr_ficha(Visual, 1, 7, Tipo4),
    valor_celda_f(2, 2, M, E5),   traducir(E5, Tipo5),    gr_ficha(Visual, 2, 2, Tipo5),
    valor_celda_f(2, 4, M, E6),   traducir(E6, Tipo6),    gr_ficha(Visual, 2, 4, Tipo6),
    valor_celda_f(2, 6, M, E7),   traducir(E7, Tipo7),    gr_ficha(Visual, 2, 6, Tipo7),
    valor_celda_f(2, 8, M, E8),   traducir(E8, Tipo8),    gr_ficha(Visual, 2, 8, Tipo8),
    valor_celda_f(3, 1, M, E9),   traducir(E9, Tipo9),    gr_ficha(Visual, 3, 1, Tipo9),
    valor_celda_f(3, 3, M, E10),  traducir(E10, Tipo10),  gr_ficha(Visual, 3, 3, Tipo10),
    valor_celda_f(3, 5, M, E11),  traducir(E11, Tipo11),  gr_ficha(Visual, 3, 5, Tipo11),
    valor_celda_f(3, 7, M, E12),  traducir(E12, Tipo12),  gr_ficha(Visual, 3, 7, Tipo12), 
    valor_celda_f(4, 2, M, E13),  traducir(E13, Tipo13),  gr_ficha(Visual, 4, 2, Tipo13),    
    valor_celda_f(4, 4, M, E14),  traducir(E14, Tipo14),  gr_ficha(Visual, 4, 4, Tipo14),
    valor_celda_f(4, 6, M, E15),  traducir(E15, Tipo15),  gr_ficha(Visual, 4, 6, Tipo15),
    valor_celda_f(4, 8, M, E16),  traducir(E16, Tipo16),  gr_ficha(Visual, 4, 8, Tipo16),
    valor_celda_f(5, 1, M, E17),  traducir(E17, Tipo17),  gr_ficha(Visual, 5, 1, Tipo17),
    valor_celda_f(5, 3, M, E18),  traducir(E18, Tipo18),  gr_ficha(Visual, 5, 3, Tipo18),
    valor_celda_f(5, 5, M, E19),  traducir(E19, Tipo19),  gr_ficha(Visual, 5, 5, Tipo19),
    valor_celda_f(5, 7, M, E20),  traducir(E20, Tipo20),  gr_ficha(Visual, 5, 7, Tipo20),
    valor_celda_f(6, 2, M, E21),  traducir(E21, Tipo21),  gr_ficha(Visual, 6, 2, Tipo21),
    valor_celda_f(6, 4, M, E22),  traducir(E22, Tipo22),  gr_ficha(Visual, 6, 4, Tipo22),
    valor_celda_f(6, 6, M, E23),  traducir(E23, Tipo23),  gr_ficha(Visual, 6, 6, Tipo23),
    valor_celda_f(6, 8, M, E24),  traducir(E24, Tipo24),  gr_ficha(Visual, 6, 8, Tipo24),
    valor_celda_f(7, 1, M, E25),  traducir(E25, Tipo25),  gr_ficha(Visual, 7, 1, Tipo25),
    valor_celda_f(7, 3, M, E26),  traducir(E26, Tipo26),  gr_ficha(Visual, 7, 3, Tipo26),
    valor_celda_f(7, 5, M, E27),  traducir(E27, Tipo27),  gr_ficha(Visual, 7, 5, Tipo27),
    valor_celda_f(7, 7, M, E28),  traducir(E28, Tipo28),  gr_ficha(Visual, 7, 7, Tipo28), 
    valor_celda_f(8, 2, M, E29),  traducir(E29, Tipo29),  gr_ficha(Visual, 8, 2, Tipo29),    
    valor_celda_f(8, 4, M, E30),  traducir(E30, Tipo30),  gr_ficha(Visual, 8, 4, Tipo30),
    valor_celda_f(8, 6, M, E31),  traducir(E31, Tipo31),  gr_ficha(Visual, 8, 6, Tipo31),
    valor_celda_f(8, 8, M, E32),  traducir(E32, Tipo32),  gr_ficha(Visual, 8, 8, Tipo32).


%%%%%%%%%%%%%%%%%%%%%%%%%% LOOP CON EVENTOS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
loop(X, Y, Visual,M,Turno,L) :-
    gr_evento(Visual,E),
    evento(X, Y, E,Visual,M,Turno,L).

evento(humano, Y, click(Fila,Columna),Visual,M,Turno,L) :-
  writeln('Estoy en click que NO agrega'),
  sformat(Msg, 'Click en (~w, ~w)', [Fila,Columna]),
    gr_estado(Visual,Msg),
    valor_celda_f(Fila, Columna, M, E),
    E >= 0,
    functor(X,posicion,2), 
    setarg(1,X,Fila),
    setarg(2,X,Columna), 
    member(X, L),
    writeln(L),
    sin_elem(L, X, L1), !,
    writeln(L1),
    traducir(E, Tipo),
    gr_ficha(Visual, Fila, Columna, Tipo),
    gr_estado(Visual,Msg),
    loop(humano, Y, Visual,M,Turno,L1).

evento(humano, Y, click(Fila,Columna),Visual,M,Turno,L) :-
	writeln('Estoy en click que agrega'),
  sformat(Msg, 'Click en (~w, ~w)', [Fila,Columna]),
    gr_estado(Visual,Msg),
    valor_celda_f(Fila, Columna, M, E),
    E >= 0,
    gr_marcador_seleccion(Visual,Fila,Columna), 
    functor(X,posicion,2), 
    setarg(1,X,Fila),
    setarg(2,X,Columna),  
    append(L, [X], L1),
    writeln(L1),
    loop(humano, Y, Visual,M,Turno,L1).

evento(humano, Y, click(Fila,Columna),Visual,M,Turno,L) :-
  sformat(Msg, 'Click en (~w, ~w)', [Fila,Columna]),
    valor_celda_f(Fila, Columna, M, -1),
    gr_estado(Visual,Msg),
    loop(humano, Y, Visual,M,Turno,L).

evento(humano, Y, fin_turno,Visual,M,Turno,[H|T]) :-
    writeln('Estoy en evento fin turno que quieri'),
    gr_estado(Visual,'Fin del turno'),
    copiar_Matriz(M, M1),
    arg(1, H, F),
    arg(2, H, C),
    writeln(H), 
    valor_celda_f(F, C, M, E),
    writeln(E), 
    writeln(Turno),
    ficha_correcta(Turno, E),
    writeln('Antes de puede comer'), 
    puede_comer(M, Turno, Posiciones),
    writeln('HOLA AMIGOS ESTAS SON LAS POSICIONES QUE PUEDEN SUCEDER:'),
    writeln(Posiciones),
    writeln('Antes de come la ficha'), 
    come_la_ficha(Posiciones, H, T), %!,
    writeln('Antes de validar_jugada.'),
    writeln(H), 
    writeln(T), 
    writeln(E), 
    validar_jugada(M1, H, T, E, Ll), !, 
    write('Fichas a Borrar:'),
    writeln(Ll),
    writeln('Antes de hacer_jugada.'),
    hacer_jugada(M, Ll, E),
    writeln('Yeay! Lograste hacerlo!'),
    dibujar(Visual, M),
    distinto(Turno, Turno1),
    no_fin_juego(Visual, M, Turno1), 
    loop(Y, humano, Visual,M,Turno1,[]).

evento(humano, Y, fin_turno,Visual,M,Turno, _) :-
    gr_estado(Visual,'Jugada invalida'),
    dibujar(Visual, M),
    loop(Y, humano, Visual,M,Turno,[]).

evento(maquina, Y, fin_turno,Visual,M,Turno, _) :- 
      minimax_levels(U),
      minimax(M, Turno, Move , U),
        dibujar(Visual, Move), 
      distinto(Turno, Turno2), 
      loop(Y, maquina, Visual, Move, Turno2, _).

evento(X, Y, guardar,Visual,M,Turno,L) :-
    gr_estado(Visual,'Guardar un juego'),
    crearListaFicha(M,ListaFichas),
    guardar_juego(Visual,Turno,humano,humano,ListaFichas),
   loop(X, Y, Visual,M,Turno,L).

evento(X, Y, cargar,Visual,M,_,_) :-
    gr_estado(Visual,'Cargar un juego'),
    cargar_juego(Visual, M, TurnoN),
  loop(X, Y, Visual,M,TurnoN,[]).

evento(X, Y, reiniciar,Visual,M,_,_) :-
    gr_estado(Visual,'Reiniciar un juego'),
    dibujarInicial(Visual, M), 
    dibujar(Visual, M),
  loop(X, Y, Visual,M,rojas,[]).

evento(X, Y, salir,Visual,M,Turno,L) :-
    (   gr_opciones(Visual, '¿Seguro?', ['Sí', 'No'], 'Sí')
    ->  true
    ;   loop(X, Y, Visual,M,Turno,L)
    ).

%%%%%%%%%%%%%%%%%%%%%%% FUNCIONES PARA GUARDAR ARCHIVO %%%%%%%%%%%%%%%%%%%%%%%%%
crearListaFicha(M,ListaFichas):-
     agregar_ficha_lista(1,1,M,[],L1),
     agregar_ficha_lista(1,3,M,L1,L2),
     agregar_ficha_lista(1,5,M,L2,L3),
     agregar_ficha_lista(1,7,M,L3,L4),
     agregar_ficha_lista(2,2,M,L4,L5),
     agregar_ficha_lista(2,4,M,L5,L6),
     agregar_ficha_lista(2,6,M,L6,L7),
     agregar_ficha_lista(2,8,M,L7,L8),
     agregar_ficha_lista(3,1,M,L8,L9),
     agregar_ficha_lista(3,3,M,L9,L10),
     agregar_ficha_lista(3,5,M,L10,L11),
     agregar_ficha_lista(3,7,M,L11,L12),
     agregar_ficha_lista(4,2,M,L12,L13),
     agregar_ficha_lista(4,4,M,L13,L14),
     agregar_ficha_lista(4,6,M,L14,L15),
     agregar_ficha_lista(4,8,M,L15,L16),
     agregar_ficha_lista(5,1,M,L16,L17),
     agregar_ficha_lista(5,3,M,L17,L18),
     agregar_ficha_lista(5,5,M,L18,L19),
     agregar_ficha_lista(5,7,M,L19,L20),
     agregar_ficha_lista(6,2,M,L20,L21),
     agregar_ficha_lista(6,4,M,L21,L22),
     agregar_ficha_lista(6,6,M,L22,L23),
     agregar_ficha_lista(6,8,M,L23,L24),
     agregar_ficha_lista(7,1,M,L24,L25),
     agregar_ficha_lista(7,3,M,L25,L26),
     agregar_ficha_lista(7,5,M,L26,L27),
     agregar_ficha_lista(7,7,M,L27,L28),
     agregar_ficha_lista(8,2,M,L28,L29),
     agregar_ficha_lista(8,4,M,L29,L30),
     agregar_ficha_lista(8,6,M,L30,L31),
     agregar_ficha_lista(8,8,M,L31,ListaFichas).

agregar_ficha_lista(I,J,M,Lista1,Lista2):-
      valor_celda_f(I,J,M,E),
      E>0,
      functor(X,ficha,3),
      setarg(1,X,I),
      setarg(2,X,J),
      traducir(E,TT),
      setarg(3,X,TT),
      concatenacion(Lista1,[X],Lista2).

agregar_ficha_lista(I,J,M,Lista1,Lista1).


guardar_juego(Visual,TurnoActual,J1,J2,ListaFichas) :-
      append([estado,TurnoActual,J1,J2],[ListaFichas],Termlist),
      Termino =..Termlist,
      gr_pregunta(Visual,'Nombre del archivo a guardar',X),
      open(X,write,Stream),
      write(Stream,Termino),
      write(Stream,'.'),
      close(Stream).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCIONES PARA CARGAR ARCHIVO %%%%%%%%%%%%%%%%%%%%%%%%%%%%

matrizparaCargar(M):-
   nuevo_valor_celda_f(1,1,M,0),
   nuevo_valor_celda_f(1,3,M,0),
   nuevo_valor_celda_f(1,5,M,0),
   nuevo_valor_celda_f(1,7,M,0),
   nuevo_valor_celda_f(2,2,M,0),
   nuevo_valor_celda_f(2,4,M,0),
   nuevo_valor_celda_f(2,6,M,0),
   nuevo_valor_celda_f(2,8,M,0),
   nuevo_valor_celda_f(3,1,M,0),
   nuevo_valor_celda_f(3,3,M,0),
   nuevo_valor_celda_f(3,5,M,0),
   nuevo_valor_celda_f(3,7,M,0),
   nuevo_valor_celda_f(4,2,M,0),
   nuevo_valor_celda_f(4,4,M,0),
   nuevo_valor_celda_f(4,6,M,0),
   nuevo_valor_celda_f(4,8,M,0),
   nuevo_valor_celda_f(5,1,M,0),
   nuevo_valor_celda_f(5,3,M,0),
   nuevo_valor_celda_f(5,5,M,0),
   nuevo_valor_celda_f(5,7,M,0),
   nuevo_valor_celda_f(6,2,M,0),
   nuevo_valor_celda_f(6,4,M,0),
   nuevo_valor_celda_f(6,6,M,0),
   nuevo_valor_celda_f(6,8,M,0),
   nuevo_valor_celda_f(7,1,M,0),
   nuevo_valor_celda_f(7,3,M,0),
   nuevo_valor_celda_f(7,5,M,0),
   nuevo_valor_celda_f(7,7,M,0),
   nuevo_valor_celda_f(8,2,M,0),
   nuevo_valor_celda_f(8,4,M,0),
   nuevo_valor_celda_f(8,6,M,0),
   nuevo_valor_celda_f(8,8,M,0).

cargar_juego(Visual, M, Turno) :-
  gr_pregunta(Visual,'Nombre del archivo a cargar',X),
  open(X,read,Stream),
  read(Stream,JuegoCargado),
  close(Stream),
  inicializar_juego(Visual,JuegoCargado, M,Turno),
  dibujar(Visual,M).

inicializar_juego(Visual,JuegoCargado, M, Turno) :-
  arg(1,JuegoCargado,Turno),
  arg(2,JuegoCargado,_),
  arg(3,JuegoCargado,_),
  arg(4,JuegoCargado,FichasParaDibujar),
  matrizparaCargar(M),
  cargar_matriz(M, FichasParaDibujar).
  
 
  
cargar_matriz(M, [H|T]):-
    arg(1,H,I),
    arg(2,H,J),
    arg(3,H,TipoFicha),
    traducir(E,TipoFicha),
    nuevo_valor_celda_f(I,J,M,E),
    cargar_matriz(M,T).

cargar_matriz(M, []).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% VALIDACION DE MOVIMIENTOS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%% COMUN ROJA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                 VALIDAR JUGADA SIMPLE                       %%%%%%% 
validar_jugada(M, posicion(F,C), [posicion(F1,C1)], 1, [posicion(F, C), posicion(F1, C1)]) :- writeln('Validando comun roja: Jugada Simple'), validar_movimiento1(M, posicion(F,C), posicion(F1, C1)).

validar_movimiento1(M, posicion(F,C), posicion(F1,C1)) :- F<8, C<8, F1 is F+1, C1 is C+1, valor_celda_f(F1, C1, M, 0).  
validar_movimiento1(M, posicion(F,C), posicion(F1,C1)) :- F<8, C>0, F1 is F+1, C1 is C-1, valor_celda_f(F1, C1, M, 0). 


validar_jugada(M, posicion(F,C), T, 1, L) :-  writeln('Validando comun roja: Comida Simple'), validar_comida1(M, posicion(F,C), T, L).

validar_comida1(M, posicion(F,C), [posicion(F1,C1)], [posicion(F,C),X,posicion(F1,C1)]) :-    writeln('hhhhh'), 
                                                                                              F<7, C<7,
                                                                                              F1 is F+2, C1 is C+2, 
                                                                                              F11 is F+1, C11 is C+1, 
                                                                                              valor_celda_f(F1, C1, M, 0),  
                                                                                              valor_celda_f(F11, C11, M, E), 
                                                                                              es_negra(E),
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11).

validar_comida1(M, posicion(F,C), [posicion(F1,C1)], [posicion(F,C),X,posicion(F1,C1)]) :-    writeln('pppipipip'),
                                                                                              F<7, C>2,
                                                                                              F1 is F+2, C1 is C-2, 
                                                                                              F11 is F+1, C11 is C-1, 
                                                                                              valor_celda_f(F1, C1, M, 0),  
                                                                                              valor_celda_f(F11, C11, M, E),
                                                                                              es_negra(E), 
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11). 

validar_comida1(M, posicion(F,C), [posicion(F1,C1)|T], [posicion(F,C),X,posicion(F1,C1)|L]) :- writeln('poop'),
                                                                                              F<7, C<7,
                                                                                              F1 is F+2, C1 is C+2, 
                                                                                              F11 is F+1, C11 is C+1, 
                                                                                              valor_celda_f(F1, C1, M, 0),  
                                                                                              valor_celda_f(F11, C11, M, E),
                                                                                              es_negra(E), 
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11), 
                                                                                              validar_comida1(M, posicion(F1, C1), T, L). 

validar_comida1(M, posicion(F,C), [posicion(F1,C1)|T], [posicion(F,C),X,posicion(F1,C1)|L]) :- writeln('comida'),
                                                                                              F<7, C>2,
                                                                                              F1 is F+2, C1 is C-2, 
                                                                                              F11 is F+1, C11 is C-1, 
                                                                                              valor_celda_f(F1, C1, M, 0),  
                                                                                              valor_celda_f(F11, C11, M, E),
                                                                                              es_negra(E), 
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11), 
                                                                                              validar_comida1(M, posicion(F1, C1), T, L). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% COMUN NEGRA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                 VALIDAR JUGADA SIMPLE                       %%%%%%% 
validar_jugada(M, posicion(F,C), [posicion(F1,C1)], 2, [posicion(F,C), posicion(F1, C1)]) :-  writeln('Validando comun negra: Jugada Simple'), validar_movimiento2(M, posicion(F,C), [posicion(F1, C1)]).

validar_movimiento2(M, posicion(F,C), [posicion(F1,C1)]) :- F>1, C>1, F1 is F-1, C1 is C-1, valor_celda_f(F1, C1, M, 0). 
validar_movimiento2(M, posicion(F,C), [posicion(F1,C1)]) :- F>1, C<8, F1 is F-1, C1 is C+1, valor_celda_f(F1, C1, M, 0). 

validar_jugada(M, posicion(F,C), T1, 2, L) :-  writeln('Validando comun negra: Comida Simple'), validar_comida2(M, posicion(F,C), T1, L).


validar_comida2(M, posicion(F,C), [posicion(F1,C1)|T], [posicion(F,C),X,posicion(F1,C1)|L]) :- 
                                                                                              F>2, C<6,
                                                                                              F1 is F-2, C1 is C+2, 
                                                                                              F11 is F-1, C11 is C+1,
                                                                                              valor_celda_f(F1, C1, M, 0), 
                                                                                              valor_celda_f(F11, C11, M, E), 
                                                                                              es_roja(E),
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11),
                                                                                              validar_comida2(M, posicion(F1, C1), T, L). 

validar_comida2(M, posicion(F,C), [posicion(F1,C1)|T], [posicion(F,C),X,posicion(F1,C1)|L]) :-
                                                                                              F>2, C>2, 
                                                                                              F1 is F-2, C1 is C-2, 
                                                                                              F11 is F-1, C11 is C-1,
                                                                                              valor_celda_f(F1, C1, M, 0), 
                                                                                              valor_celda_f(F11, C11, M, E), 
                                                                                              es_roja(E),
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11),
                                                                                              validar_comida2(M, posicion(F1, C1), T, L).

validar_comida2(M, posicion(F,C), [posicion(F1,C1)], [posicion(F,C),X,posicion(F1,C1)]) :-  
                                                                                            F>2, C<7,
                                                                                            F1 is F-2, C1 is C+2, 
                                                                                            F11 is F-1, C11 is C+1, 
                                                                                            valor_celda_f(F1, C1, M, 0),  
                                                                                            valor_celda_f(F11, C11, M, E),
                                                                                            es_roja(E), 
                                                                                            functor(X,posicion,2), 
                                                                                            setarg(1,X,F11), setarg(2,X,C11). 

validar_comida2(M, posicion(F,C), [posicion(F1,C1)], [posicion(F,C),X,posicion(F1,C1)]) :-    
                                                                                              F>2, C>2,
                                                                                              F1 is F-2, C1 is C-2, 
                                                                                              F11 is F-1, C11 is C-1,
                                                                                              valor_celda_f(F1, C1, M, 0), 
                                                                                              valor_celda_f(F11, C11, M, E), 
                                                                                              es_roja(E),
                                                                                              functor(X,posicion,2), 
                                                                                              setarg(1,X,F11), setarg(2,X,C11). 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% DAMAS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

validar_jugada(M, posicion(F,C), [posicion(X,Y)], Q, L) :-  Q>2, validar_diagonal(M, Q, posicion(F,C), [posicion(X,Y)], L).

validar_diagonal(M, Q, posicion(F,C), [posicion(F1,C1)], List) :- 
              valor_celda_f(F1, C1, M, 0),
              X is F-F1, XX is C-C1, 
              I is abs(X), I is abs(XX), 
              valor_celda_f(F1, C1, M, 0),
              writeln('Antes de validando_diagonal'),
              writeln(I), 
              que_diagonal(X, XX, A), 
              validando_diagonal(M, Q, A, I, posicion(F,C), List),
              writeln('Depsues de validando_diagonal'). 


que_diagonal(X, XX, 1) :- X >= 0, XX >= 0. 
que_diagonal(X, XX, 2) :- X =< 0, XX =< 0. 
que_diagonal(X, XX, 3) :- X =< 0, XX >= 0. 
que_diagonal(X, XX, 4) :- X >= 0, XX =< 0. 


%%% DIAGONAL 1
validando_diagonal(M, Q, 1, I, posicion(F,C), L1) :- 
              I > 2,
              II is I-2,
              writeln('Entrando en B'), 
              F11 is F-2, C11 is C-2,
              F1 is F-1, C1 is C-1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11),
              setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1),
              setarg(2,X,C1), 
              validando_restantes1(M, 1, II, T, L), 
              append([posicion(F,C),X,T], L, L1). 

validando_diagonal(M, Q, 1, 2, posicion(F,C), [posicion(F,C),X,T]) :- 
              writeln('Entrando en B'), 
              F11 is F-2, C11 is C-2,
              F1 is F-1, C1 is C-1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11),
              setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1),
              setarg(2,X,C1). 

validando_diagonal(M, Q, 1, I, posicion(F,C), L1) :- 
            writeln('Entrando a C'),
            I >= 2,
            II is I-1, 
            F11 is F-1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11), !,
            validando_diagonal(M, Q, 1, II, X, L), 
            append([posicion(F,C),X], L, L1).

validando_diagonal(M, Q, 1, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Entrando a D'),
            F11 is F-1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11). 

validando_restantes1(M, 1, I, posicion(F,C), L) :- 
            I >= 2,
            II is I-1, 
            F11 is F-1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11),
            validando_restantes1(M, 1, II, X, L).

validando_restantes1(M, 1, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Estoy haciendo est11111'),
            F11 is F-1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11). 

%%% DIAGONAL 2
validando_diagonal(M, Q, 2, I, posicion(F,C), L1) :- 
              I > 2,
              II is I-2,
              writeln('Entrando en B'), 
              F11 is F+2, C11 is C+2,
              F1 is F+1, C1 is C+1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11), setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1), setarg(2,X,C1), 
              validando_restantes2(M, 2, II, T, L), 
              append([posicion(F,C),X,T], L, L1). 

validando_diagonal(M, Q, 2, 2, posicion(F,C), [posicion(F,C),X,T]) :- 
              writeln('Entrando en B'), 
              F11 is F+2, C11 is C+2,
              F1 is F+1, C1 is C+1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11), setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1), setarg(2,X,C1). 

validando_diagonal(M, Q, 2, I, posicion(F,C), L1) :- 
            writeln('Entrando a C'),
            I >= 2,
            II is I-1, 
            F11 is F+1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11), !,
            validando_diagonal(M, Q, 2, II, X, L), 
            append([posicion(F,C),X], L, L1).

validando_diagonal(M, Q, 2, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Entrando a D'),
            F11 is F+1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11). 

validando_restantes2(M, 2, I, posicion(F,C), L) :- 
            I >= 2,
            II is I-1, 
            F11 is F+1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11),
            validando_restantes2(M, 2, II, X, L).

validando_restantes2(M, 2, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Estoy haciendo est11111'),
            F11 is F+1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11). 



%%% DIAGONAL 3
validando_diagonal(M, Q, 3, I, posicion(F,C), L1) :- 
              I > 2,
              II is I-2,
              writeln('Entrando en B'), 
              F11 is F+2, C11 is C-2,
              F1 is F+1, C1 is C-1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11), setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1), setarg(2,X,C1), 
              validando_restantes3(M, 3, II, T, L), 
              append([posicion(F,C),X,T], L, L1). 


validando_diagonal(M, Q, 3, 2, posicion(F,C), [posicion(F,C),X,T]) :- 
              writeln('Entrando en B'), 
              F11 is F+2, C11 is C-2,
              F1 is F+1, C1 is C-1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11),
              setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1),
              setarg(2,X,C1). 

validando_diagonal(M, Q, 3, I, posicion(F,C), L1) :- 
            writeln('Entrando a C'),
            I >= 2,
            II is I-1, 
            F11 is F+1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11), !,
            validando_diagonal(M, Q, 3, II, X, L), 
            append([posicion(F,C),X], L, L1).

validando_diagonal(M, Q, 3, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Entrando a D'),
            F11 is F+1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11). 

validando_restantes3(M, 3, I, posicion(F,C), L) :- 
            I >= 2,
            II is I-1, 
            F11 is F+1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11),
            validando_restantes3(M, 3, II, X, L).

validando_restantes3(M, 3, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Estoy haciendo est11111'),
            F11 is F+1, C11 is C-1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11). 


%%% DIAGONAL 4
validando_diagonal(M, Q, 4, I, posicion(F,C), L1) :- 
              I > 2,
              II is I-2,
              F11 is F-2, C11 is C+2,
              F1 is F-1, C1 is C+1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0),
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11), setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1), setarg(2,X,C1), 
              writeln('ANTES DE RESTANTES'),
              validando_restantes4(M, 4, II, T, L), 
              append([posicion(F,C),X,T], L, L1). 

validando_diagonal(M, Q, 4, 2, posicion(F,C), [posicion(F,C),X,T]) :- 
              writeln('Entrando en PIZZZZA'), 
              F11 is F-2, C11 is C+2,
              F1 is F-1, C1 is C+1,
              valor_celda_f(F1, C1, M, E),  
              valor_celda_f(F11, C11, M, 0), 
              es_contraria(Q, E), !,
              nuevo_valor_celda_f(F1, C1, M, -2), 
              functor(T,posicion,2), 
              setarg(1,T,F11), setarg(2,T,C11),  
              functor(X,posicion,2), 
              setarg(1,X,F1), setarg(2,X,C1). 

validando_diagonal(M, Q, 4, I, posicion(F,C), L1) :- 
            writeln('Entrando a WOOORK'),
            I >= 2,
            II is I-1, 
            F11 is F-1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11), !,
            validando_diagonal(M, Q, 4, II, X, L), 
            append([posicion(F,C),X], L, L1).

validando_diagonal(M, Q, 4, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Entrando a DSJFHSDFDLS'),
            F11 is F-1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11),
            setarg(2,X,C11). 

validando_restantes4(M, 4, I, posicion(F,C), L) :- 
            I >= 2,
            II is I-1, 
            F11 is F-1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11),
            validando_restantes4(M, 4, II, X, L).

validando_restantes4(M, 4, 1, posicion(F,C), [posicion(F,C),X]) :- 
            writeln('Estoy haciendo est11111'),
            F11 is F-1, C11 is C+1,
            valor_celda_f(F11, C11, M, 0),  
            functor(X,posicion,2), 
            setarg(1,X,F11), setarg(2,X,C11). 

validar_jugada(M, posicion(F,C), [posicion(F1,C1) |T], Q, L) :-  
                                  Q>2, 
                                  writeln('ESTOY EN EL VALIDAR QUE QUIERO'),
                                  writeln(T), 
                                  writeln(TT),
                                  writeln('Estoy en validar de una'),
                                  validar_jugada(M, posicion(F,C), posicion(F1,C1), Q, L1), 
                                  writeln('Estoy por validar las siguientes'),
                                  validar_jugada(M, posicion(F1,C1), T, Q, L2), 
                                  append(L1, L2, L). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% PUEDE COMER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

puede_comer(M, Turno, Posiciones) :-
              crearListaFicha(M, L), 
              listaFichaColor(L, Turno, L1),
              hay_comida(M, L1, Posiciones), !. 

hay_comida(M, [H|T], Posiciones) :-
                    writeln('MIRA DONDE ENTRE'), 
                    arg(1, H, F), arg(2, H, C), 
                    valor_celda_f(F, C, M, 1), 
                    hay_comida_comun_rojo(M, F, C, F2, C2),
                    functor(X,jugadas_comida,4), 
                    setarg(1,X,F),
                    setarg(2,X,C),
                    setarg(3,X,F2),
                    setarg(4,X,C2),
                    hay_comida(M, T, Pos1), 
                    append([X], Pos1, Posiciones).
hay_comida(M, [H|T], Posiciones) :- 
                    writeln('SABEMOS'), 
                    arg(1, H, F), arg(2, H, C), 
                    valor_celda_f(F, C, M, 2),
                    hay_comida_comun_negro(M, F, C, F2, C2),
                    functor(X,jugadas_comida,4), 
                    setarg(1,X,F),
                    setarg(2,X,C),
                    setarg(3,X,F2),
                    setarg(4,X,C2),
                    hay_comida(M, T, Pos1),
                    append([X], Pos1, Posiciones).
hay_comida(M, [H|T], Posiciones) :- 
                    writeln('LA PUTA MADRE'), 
                    arg(1, H, F), arg(2, H, C),  
                    valor_celda_f(F, C, M, E), 
                    E>2, 
                    hay_comida_dama1(M, F, C, F, C, E, Pos),
                    hay_comida(M, T, Pos1), 
                    append(Pos, Pos1, Posiciones).
hay_comida(M, [H|T], Posiciones) :- 
                    writeln('LA PUTA MADRE'), 
                    arg(1, H, F), arg(2, H, C),  
                    valor_celda_f(F, C, M, E), 
                    E>2, 
                    hay_comida_dama2(M, F, C, F, C, E, Pos),
                    hay_comida(M, T, Pos1), 
                    append(Pos, Pos1, Posiciones).
hay_comida(M, [H|T], Posiciones) :- 
                    writeln('LA PUTA MADRE'), 
                    arg(1, H, F), arg(2, H, C),  
                    valor_celda_f(F, C, M, E), 
                    E>2, 
                    hay_comida_dama3(M, F, C, F, C, E, Pos),
                    hay_comida(M, T, Pos1), 
                    append(Pos, Pos1, Posiciones).
hay_comida(M, [H|T], Posiciones) :- 
                    writeln('LA PUTA MADRE'), 
                    arg(1, H, F), arg(2, H, C),  
                    valor_celda_f(F, C, M, E), 
                    E>2, 
                    hay_comida_dama4(M, F, C, F, C, E, Pos),
                    hay_comida(M, T, Pos1), 
                    append(Pos, Pos1, Posiciones).
hay_comida(M, [_|T], Posiciones) :-
                    writeln('TMDE DEL ORTO'),
                    hay_comida(M, T, Posiciones).
 
hay_comida(M, [], []). 

hay_comida_comun_rojo(M, F, C, F2, C2) :- C>2, F<7, F1 is F+1, C1 is C-1, F2 is F+2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_negra(E), valor_celda_f(F2, C2, M, 0). 
hay_comida_comun_rojo(M, F, C, F2, C2) :- C<7, F<7, F1 is F+1, C1 is C+1, F2 is F+2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_negra(E), valor_celda_f(F2, C2, M, 0). 

hay_comida_comun_negro(M, F, C, F2, C2) :- C>2, F>2, F1 is F-1, C1 is C-1, F2 is F-2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_roja(E), valor_celda_f(F2, C2, M, 0). 
hay_comida_comun_negro(M, F, C, F2, C2) :- C<7, F>2, F1 is F-1, C1 is C+1, F2 is F-2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_roja(E), valor_celda_f(F2, C2, M, 0). 

%DIAGONAL 1
hay_comida_dama1(M, F, C, F1, C1, I, Pos) :- writeln('LASSAGNA'), C<7, F<7, F2 is F1+1, C2 is C1+1, valor_celda_f(F2, C2, M, E), es_contraria(I, E), restantes1(M, F, C, F2, C2, [], Pos).
hay_comida_dama1(M, F, C, F1, C1, I, Pos) :- writeln('HAMBURGUESAS'), C<8, F<8, F2 is F1+1, C2 is C1+1, valor_celda_f(F2, C2, M, 0), hay_comida_dama1(M, F, C, F2, C2, I, Pos). 

restantes1(M, F, C, F1, C1, Pos, Pos1) :- 
          F<8, C<8, F2 is F1+1, C2 is C1+1, valor_celda_f(F2, C2, M, 0),  !, 
          restantes1(M, F, C, F2, C2, Pos, PosA), 
          functor(X,jugadas_comida,4), setarg(1,X,F), setarg(2,X,C), setarg(3,X,F2), setarg(4,X,C2),
          append([X], PosA, Pos1). 
restantes1(M, F, C, F1, C1, Pos, Pos). 


%DIAGONAL 2
hay_comida_dama2(M, F, C, F1, C1, I, Pos) :- writeln('LASSAGNA'), C<7, F>2, F2 is F1-1, C2 is C1+1, valor_celda_f(F2, C2, M, E), es_contraria(I, E), restantes2(M, F, C, F2, C2, [], Pos).
hay_comida_dama2(M, F, C, F1, C1, I, Pos) :- writeln('HAMBURGUESAS'), C<8, F>1, F2 is F1-1, C2 is C1+1, valor_celda_f(F2, C2, M, 0), hay_comida_dama2(M, F, C, F2, C2, I, Pos). 

restantes2(M, F, C, F1, C1, Pos, Pos1) :- 
          F>1, C<8, F2 is F1-1, C2 is C1+1, valor_celda_f(F2, C2, M, 0),  !, 
          restantes2(M, F, C, F2, C2, Pos, PosA), 
          functor(X,jugadas_comida,4), setarg(1,X,F), setarg(2,X,C), setarg(3,X,F2), setarg(4,X,C2),
          append([X], PosA, Pos1). 
restantes2(M, F, C, F1, C1, Pos, Pos). 

%DIAGONAL 3
hay_comida_dama3(M, F, C, F1, C1, I, Pos) :- writeln('LASSAGNA'), C>2, F>2, F2 is F1-1, C2 is C1-1, valor_celda_f(F2, C2, M, E), es_contraria(I, E), restantes3(M, F, C, F2, C2, [], Pos).
hay_comida_dama3(M, F, C, F1, C1, I, Pos) :- writeln('HAMBURGUESAS'), C>1, F>1, F2 is F1-1, C2 is C1-1, valor_celda_f(F2, C2, M, 0), hay_comida_dama3(M, F, C, F2, C2, I, Pos). 

restantes3(M, F, C, F1, C1, Pos, Pos1) :- 
          F>1, C>1, F2 is F1-1, C2 is C1-1, valor_celda_f(F2, C2, M, 0),  !, 
          restantes3(M, F, C, F2, C2, Pos, PosA), 
          functor(X,jugadas_comida,4), setarg(1,X,F), setarg(2,X,C), setarg(3,X,F2), setarg(4,X,C2),
          append([X], PosA, Pos1). 
restantes3(M, F, C, F1, C1, Pos, Pos). 

%DIAGONAL 4
hay_comida_dama4(M, F, C, F1, C1, I, Pos) :- writeln('LASSAGNA'), C>2, F<7, F2 is F1+1, C2 is C1-1, valor_celda_f(F2, C2, M, E), es_contraria(I, E), restantes4(M, F, C, F2, C2, [], Pos).
hay_comida_dama4(M, F, C, F1, C1, I, Pos) :- writeln('HAMBURGUESAS'), C>1, F<8, F2 is F1+1, C2 is C1-1, valor_celda_f(F2, C2, M, 0), hay_comida_dama4(M, F, C, F2, C2, I, Pos). 

restantes4(M, F, C, F1, C1, Pos, Pos1) :- 
          F<8, C>1, F2 is F1+1, C2 is C1-1, valor_celda_f(F2, C2, M, 0),  !, 
          restantes4(M, F, C, F2, C2, Pos, PosA), 
          functor(X,jugadas_comida,4), setarg(1,X,F), setarg(2,X,C), setarg(3,X,F2), setarg(4,X,C2),
          append([X], PosA, Pos1). 
restantes4(M, F, C, F1, C1, Pos, Pos). 

%%%%%%% SI COME LA FICHA CORRECTA
come_la_ficha([], H, T). 
come_la_ficha(P, H, [T1|T2]) :-  validar_posicion(P, H, T1).

validar_posicion([P1|P2], posicion(F,C), T) :- 
                    arg(1,P1,F),
                    arg(2,P1,C),
                    arg(1,T,F1),
                    arg(2,T,C1),
                    arg(3,P1,F1),
                    arg(4,P1,C1). 
validar_posicion([P1|P2], H, T) :- 
                    validar_posicion(P2, H, T). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% FIN JUEGO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
no_fin_juego(Visual, M, Turno) :- hay_fichas_rojas(M), hay_fichas_negras(M), puede_moverse(M, Turno), \+(dama_dama(M)). 
no_fin_juego(Visual, M, Turno) :- gr_estado(Visual,'Fin del juego!!!!').

hay_fichas_rojas(M) :- findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,1)), ListaRojas),
                      length(ListaRojas, V), 
                      findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,3)), ListaRojas2),
                      length(ListaRojas2, V1), 
                      Rojas is V+V1, Rojas > 0. 


hay_fichas_negras(M) :- findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,2)), ListaNegra),
                      length(ListaNegra, V), 
                      findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,4)), ListaNegra2),
                      length(ListaNegra2, V1), 
                      Negra is V+V1, Negra > 0. 

dama_dama(M) :-  
              findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,1)), ListaComunRoja),
              length(ListaComunRoja, 0),
              findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,2)), ListaComunNegra),
              length(ListaComunNegra, 0),
              findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,3)), ListaDamaRoja),
              length(ListaDamaRoja, 1),
              findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,4)), ListaDamaNegra),
              length(ListaDamaNegra, 1). 

listaFichaColor([], Turno, []). 
listaFichaColor([ficha(I, J, TipoFicha)|T], Turno, L1):- 
            traducir(E, TipoFicha), 
            ficha_correcta(Turno, E), !,
            listaFichaColor(T, Turno, L),
            append(L, [posicion(I,J)], L1).
listaFichaColor([ficha(_, _, _)|T], Turno, L) :-
            listaFichaColor(T, Turno, L).

puede_moverse(M, Turno) :- crearListaFicha(M, L), listaFichaColor(L, Turno, L1), hay_movimiento(M, L1). 

hay_movimiento(M, [H|T]) :- 
                    arg(1,H,F),
                    arg(2,H,C),
                    valor_celda_f(F, C, M, 1),  
                    hay_movimiento_comun_rojo(M, F,C).
hay_movimiento(M, [H|T]) :- 
                    arg(1,H,F),
                    arg(2,H,C),
                    valor_celda_f(F, C, M, 2),  
                    hay_movimiento_comun_negro(M, F,C).
hay_movimiento(M, [H|T]) :- 
                    arg(1,H,F),
                    arg(2,H,C),
                    valor_celda_f(F, C, M, E),
                    E>2, 
                    hay_movimiento_dama(M, F, C, E).

hay_movimiento(M, [H|T]) :-
                    hay_movimiento(M, T).


hay_movimiento_comun_rojo(M, F, C) :- C>1, F<8, F1 is F+1, C1 is C-1, valor_celda_f(F1, C1, M, 0).  
hay_movimiento_comun_rojo(M, F, C) :- C<8, F<8, F1 is F+1, C1 is C+1, valor_celda_f(F1, C1, M, 0). 
hay_movimiento_comun_rojo(M, F, C) :- C>2, F<7, F1 is F-1, C1 is C-1, F2 is F-2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_negra(E), valor_celda_f(F2, C2, M, 0). 
hay_movimiento_comun_rojo(M, F, C) :- C<7, F<7, F1 is F+1, C1 is C+1, F2 is F+2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_negra(E), valor_celda_f(F2, C2, M, 0). 

hay_movimiento_comun_negro(M, F, C) :- C>1, F>1, F1 is F-1, C1 is C-1, valor_celda_f(F1, C1, M, 0).  
hay_movimiento_comun_negro(M, F, C) :- C<8, F>1, F1 is F-1, C1 is C+1, valor_celda_f(F1, C1, M, 0). 
hay_movimiento_comun_negro(M, F, C) :- C>2, F>2, F1 is F-1, C1 is C-1, F2 is F-2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_roja(E), valor_celda_f(F2, C2, M, 0). 
hay_movimiento_comun_negro(M, F, C) :- C<7, F>2, F1 is F-1, C1 is C+1, F2 is F-2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_roja(E), valor_celda_f(F2, C2, M, 0). 


hay_movimiento_dama(M, F, C, E) :- C>1, F<8, F1 is F+1, C1 is C-1, valor_celda_f(F1, C1, M, 0).  
hay_movimiento_dama(M, F, C, E) :- C<8, F<8, F1 is F+1, C1 is C+1, valor_celda_f(F1, C1, M, 0). 
hay_movimiento_dama(M, F, C, E) :- C>1, F>1, F1 is F-1, C1 is C-1, valor_celda_f(F1, C1, M, 0).  
hay_movimiento_dama(M, F, C, E) :- C<8, F>1, F1 is F-1, C1 is C+1, valor_celda_f(F1, C1, M, 0). 
hay_movimiento_dama(M, F, C, I) :- C>2, F<7, F1 is F-1, C1 is C-1, F2 is F-2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_contraria(I, E), valor_celda_f(F2, C2, M, 0). 
hay_movimiento_dama(M, F, C, I) :- C<7, F<7, F1 is F+1, C1 is C+1, F2 is F+2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_contraria(I, E), valor_celda_f(F2, C2, M, 0). 
hay_movimiento_dama(M, F, C, I) :- C>2, F>2, F1 is F-1, C1 is C-1, F2 is F-2, C2 is C-2, valor_celda_f(F1, C1, M, E), es_contraria(I, E), valor_celda_f(F2, C2, M, 0). 
hay_movimiento_dama(M, F, C, I) :- C<7, F>2, F1 is F-1, C1 is C+1, F2 is F-2, C2 is C+2, valor_celda_f(F1, C1, M, E), es_contraria(I, E), valor_celda_f(F2, C2, M, 0). 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%% EJECUCION DE LA JUGADA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSFOMAR COMUN ROJA EN DAMA ROJA
hacer_jugada(M, [H], 1):- 
    write(H),
    arg(1, H, 8),
    arg(2, H, Columna),
    write(Fila), write(Columna),
    nuevo_valor_celda_f(8, Columna, M, 3).

%TRANSFOMAR COMUN NEGRA EN DAMA NEGRA
hacer_jugada(M, [H], 2):- 
    write(H),
    arg(1, H, 1),
    arg(2, H, Columna),
    write(Fila), write(Columna),
    nuevo_valor_celda_f(1, Columna, M, 4). 

hacer_jugada(M, [H], E):- 
    write(H),
    arg(1, H, Fila),
    arg(2, H, Columna),
    write(Fila), write(Columna),
    nuevo_valor_celda_f(Fila, Columna, M, E). 

hacer_jugada(M, [H|T], E):-
    hacer_jugada(M, T, E),
    arg(1, H, Fila),
    arg(2, H, Columna),
    nuevo_valor_celda_f(Fila, Columna, M, 0). 

copiar_Matriz(M,M1) :-
    matriz_f(8,8,-1,M1),
    valor_celda_f(1, 1, M, E1),   nuevo_valor_celda_f(1, 1, M1, E1),
    valor_celda_f(1, 3, M, E2),   nuevo_valor_celda_f(1, 3, M1, E2),
    valor_celda_f(1, 5, M, E3),   nuevo_valor_celda_f(1, 5, M1, E3),
    valor_celda_f(1, 7, M, E4),   nuevo_valor_celda_f(1, 7, M1, E4),
    valor_celda_f(2, 2, M, E5),   nuevo_valor_celda_f(2, 2, M1, E5),
    valor_celda_f(2, 4, M, E6),   nuevo_valor_celda_f(2, 4, M1, E6),
    valor_celda_f(2, 6, M, E7),   nuevo_valor_celda_f(2, 6, M1, E7),
    valor_celda_f(2, 8, M, E8),   nuevo_valor_celda_f(2, 8, M1, E8),
    valor_celda_f(3, 1, M, E9),   nuevo_valor_celda_f(3, 1, M1, E9),
    valor_celda_f(3, 3, M, E10),  nuevo_valor_celda_f(3, 3, M1, E10),
    valor_celda_f(3, 5, M, E11),  nuevo_valor_celda_f(3, 5, M1, E11),
    valor_celda_f(3, 7, M, E12),  nuevo_valor_celda_f(3, 7, M1, E12),
    valor_celda_f(4, 2, M, E13),  nuevo_valor_celda_f(4, 2, M1, E13),   
    valor_celda_f(4, 4, M, E14),  nuevo_valor_celda_f(4, 4, M1, E14),
    valor_celda_f(4, 6, M, E15),  nuevo_valor_celda_f(4, 6, M1, E15),
    valor_celda_f(4, 8, M, E16),  nuevo_valor_celda_f(4, 8, M1, E16),
    valor_celda_f(5, 1, M, E17),  nuevo_valor_celda_f(5, 1, M1, E17),
    valor_celda_f(5, 3, M, E18),  nuevo_valor_celda_f(5, 3, M1, E18),
    valor_celda_f(5, 5, M, E19),  nuevo_valor_celda_f(5, 5, M1, E19),
    valor_celda_f(5, 7, M, E20),  nuevo_valor_celda_f(5, 7, M1, E20),
    valor_celda_f(6, 2, M, E21),  nuevo_valor_celda_f(6, 2, M1, E21),
    valor_celda_f(6, 4, M, E22),  nuevo_valor_celda_f(6, 4, M1, E22),
    valor_celda_f(6, 6, M, E23),  nuevo_valor_celda_f(6, 6, M1, E23),
    valor_celda_f(6, 8, M, E24),  nuevo_valor_celda_f(6, 8, M1, E24),
    valor_celda_f(7, 1, M, E25),  nuevo_valor_celda_f(7, 1, M1, E25),
    valor_celda_f(7, 3, M, E26),  nuevo_valor_celda_f(7, 3, M1, E26),
    valor_celda_f(7, 5, M, E27),  nuevo_valor_celda_f(7, 5, M1, E27),
    valor_celda_f(7, 7, M, E28),  nuevo_valor_celda_f(7, 7, M1, E28), 
    valor_celda_f(8, 2, M, E29),  nuevo_valor_celda_f(8, 2, M1, E29),    
    valor_celda_f(8, 4, M, E30),  nuevo_valor_celda_f(8, 4, M1, E30),
    valor_celda_f(8, 6, M, E31),  nuevo_valor_celda_f(8, 6, M1, E31),
    valor_celda_f(8, 8, M, E32),  nuevo_valor_celda_f(8, 8, M1, E32).

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pizza(J) :- write('ACA ESTOU').

cambiar(min, max). 
cambiar(max, min). 

puntaje_Rojas(M, Total) :-
   findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,1)), ListaRojas),
   length(ListaRojas, V),
   findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,3)), ListaRojas2),
   length(ListaRojas2, V1), 
   ComunRojas is V*1, 
   DamasRojas is V1*100, 
   Total is ComunRojas+DamasRojas. 

puntaje_Negras(M, Total) :-
   findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,2)), ListaNegras),
   length(ListaNegras, V),
   findall(posicion(X,Y), (between(1,8,X), between(1,8,Y), valor_celda_f(X,Y,M,4)), ListaNegras2),
   length(ListaNegras2, V1), 
   ComunNegras is V*1, 
   DamasNegras is V1*100, 
   Total is ComunNegras+DamasNegras. 

%%%%%%%%%%%%%%%%%% FIN DE JUEGO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
es_fin_juego(M, rojas, 1000000) :-
  puntaje_Negras(M, 0). 

es_fin_juego(M, negras, 1000000) :-
  puntaje_Rojas(M, 0).

es_fin_juego(M, rojas, -1000000) :-
  puntaje_Rojas(M, 0).

es_fin_juego(M, negras, -1000000) :-
  puntaje_Negras(M, 0).  

es_fin_juego(M, _, 0) :-
  puntaje_Rojas(M, 100), 
  puntaje_Negras(M, 100). 

no_es_fin_juego(M) :- 
  es_fin_juego(M, _, _), 
  !,
  fail. 
no_es_fin_juego(M). 


%%%%%%%%%%%%%%%%%%%%%% EVALUAR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
evaluar(M, Turno, V) :-
  es_fin_juego(M, Turno, V3), 
  V is V3. 

evaluar(M, negras, Total) :-
  puntaje_Rojas(M, T1), 
  puntaje_Negras(M, T2), 
  writeln('Evaluar negras'), 
  Total is T2-T1, 
  writeln(M),
  writeln(Total).

evaluar(M, rojas, Total) :-
  puntaje_Rojas(M, T1), 
  puntaje_Negras(M, T2), 
  writeln('Estoy Evaluar rojas'), 
  Total is T1-T2, 
  writeln(M),
  writeln(Total). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% MINIMAX/4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
minimax(M, Turno, BestMove, Prof) :-
  minimax(M, Turno, BestMove, _, Prof, max, Turno, -1000000, 1000000).
                    
%%%%%%%%%%%%%%%%%%%%%%%%%% MINIMAX/9 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% MINIMAX (MATRIZ, TURNO, MEJOR JUGADA, MEJOR VALOR, PROFUNDIDAD, MAX/MIN, AEVALUAR, ALPHA, BETA)
minimax(M, Turno2, _, Val, 0, _, AEvaluar, _, _) :-
  writeln(AEvaluar),
  writeln('11111111111111'),
  evaluar(M, AEvaluar, Val).

minimax(M, _, _, Val, Nivel, _, AEvaluar, _, _) :-
  writeln('222222222222222'),
  es_fin_juego(M, AEvaluar, Val).

minimax(M, Turno, BestMove, BestValue, Nivel, MaxMin, AEvaluar, Alpha, Beta) :-
  writeln('33333333333333'),
  pizza(J),
  findall(M, ((between(1,8,X)), (between(1,8,Y)), write(X), write(Y), writeln(''), valor_celda_f(X, Y, M, E), ficha_correcta(Turno, E), validar_jugada(M, posicion(X,Y), T, E, L), hacer_jugada(M, L, E), writeln(''), writeln(M), writeln('')), MList),
  obtenerMejorMov(MList, Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta).


%%%%%%%%%%%%%%%%% OBTENER EL MEJOR MOVIMIENTO 
obtenerMejorMov([Nuevas], Turno, Nivel, BestMove, Value, MaxMin, AEvaluar, Alpha, Beta) :-
  writeln('AAAAAAAAAAAAAAAAA'),
  distinto(Turno, Turno2), %CAMBIA EL Turno
  cambiar(MaxMin, MaxMin2), 
  Nivel2 is Nivel-1, 
  minimax(Nuevas, Turno2, BestMove, Value, Nivel2, MaxMin2, AEvaluar, Alpha, Beta). 

obtenerMejorMov([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta) :-
  writeln('BBBBBBBBBBBBBBBB'),
  distinto(Turno, Turno2), 
  cambiar(MaxMin, MaxMin2), 
  Nivel2 is Nivel-1, 
  minimax(Nuevas, Turno2, BestMove, ValueH, Nivel2, MaxMin2, AEvaluar, Alpha, Beta),
  pizza(A), 
  ((MaxMin = max)
    -> 
      (si_es_max([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta, ValueH))
    ; 
       (si_es_min([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta, ValueH))
  ), !. 


si_es_max([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta, ValueH) :- 
      NuevoAlpha is max(Alpha, ValueH), Beta =< NuevoAlpha, 
      BestValue is NuevoAlpha, BestMove = Nuevas. 

si_es_max([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta, ValueH) :- 
      NuevoAlpha is max(Alpha, ValueH), Beta > NuevoAlpha, 
      obtenerMejorMov(T, Turno, Nivel, Mov2, Value2, MaxMin, AEvaluar, NuevoAlpha, Beta),
      obtenerMejor(Nuevas, ValueH, Mov2, Value2, MaxMin, BestMove, BestValue).


si_es_min([Nuevas|T], Turno, Nivel, Nuevas, NuevoBeta, MaxMin, AEvaluar, Alpha, Beta, ValueH) :- 
      NuevoBeta is min(Beta, ValueH), NuevoBeta =< Alpha,
      BestValue is NuevoBeta, BestMove = Nuevas. 

si_es_min([Nuevas|T], Turno, Nivel, BestMove, BestValue, MaxMin, AEvaluar, Alpha, Beta, ValueH) :- 
      NuevoBeta is min(Beta, ValueH), NuevoBeta > Alpha,
      obtenerMejorMov(T, Turno, Nivel, Mov2, Value2, MaxMin, AEvaluar, Alpha, NuevoBeta), 
      obtenerMejor(Nuevas, ValueH, Mov2, Value2, MaxMin, BestMove, BestValue).

%%%%%%%%%% AUXILIARES
obtenerMejor(M1,Val1,_,Val2,max,M1,Val1):- Val1 > Val2.
obtenerMejor(M1,Val1,_,Val1,max,M1,Val1).
obtenerMejor(_,Val1,M2,Val2,max,M2,Val2):- Val2 > Val1.
obtenerMejor(M1,Val1,_,Val2,min,M1,Val1):- Val1 < Val2.
obtenerMejor(M1,Val1,_,Val1,min,M1,Val1).
obtenerMejor(_,Val1,M2,Val2,min,M2,Val2):- Val2 < Val1.