%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------
%   (1) Predicados sobre listas.
%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------

%largo(+L,?N), siendo N el largo de la lista L.
largo([],0).  % largo de la lista vacia es 0
largo([H|T], X) :- largo(T, N), X is N+1.  % largo de una lista es 1 + largo de la cola de la lista.


%todos_iguales(?L,?E), todos los elemento de la lista L son iguales a E.
todos_iguales([X],X). %si tiene un solo elemento.
todos_iguales([H|T], H):-todos_iguales(T, H). % si la cabeza cumple la igualdad, me fijo la cola.


%fibonacci3_simple(+N,?F) F es Fibonacci3 sin acumuladores del numero N
fibonacci3_simple(0, 1).
fibonacci3_simple(1, 1).
fibonacci3_simple(2, 1).
fibonacci3_simple(X, F) :- X>0,X < 16, A is X-1, B is X-2, C is X-3,
fibonacci3_simple(A, F1), fibonacci3_simple(B, F2),
fibonacci3_simple(C, F3), F is F1+F2+F3.  % N debe ser un numero entre 0 y 30.
% F se define como fib(N)= fib(N-1) + fib(N-2)+ fib(N-3)


%fibonacci3(+N, ?F) F es Fibonacci3 utilizando acumuladores del numero N
fibonacci3(0,1).
fibonacci3(1,1).
fibonacci3(2,1).
fibonacci3(N,F):- fib1(N,1,1,1,F).  % F1, F2, F3 comienzan valiendo 1, corresponden a las clausulas base.
fib1(3,F1,F2,F3,F):- F is F1+F2+F3.
fib1(N,F1,F2,F3,F):- N>0,N<151,F4 is F1+F2+F3,  N1 is N-1, fib1(N1,F2,F3,F4,F).  % F1,F2,F3 son los acumuladores.


%concatenacion(?L1, ?L2, ?L) % La lista L es la concatenacion de L1 y L2
concatenacion([], L, L). % Concatena la lista vacia con L2 da la lista L2
concatenacion([H|L1], L2, [H|L]):- concatenacion(L1, L2, L). % Pongo la cabeza de L1 en L y continuo con la cola.


%sublista(?L, ?Sub) % Sub es una sublista de la lista L.
sufijo(S,L) :- append(_,S,L), S\=[].   %S es un sufijo de L.
prefijo(P,L) :- append(P,_,L), P\=[]. %P es un sufijo de P
sublista(_,[]). %El vacio siempre es una sublista
sublista(L,Sub) :- sufijo(S,L),prefijo(Sub,S).  % Una sublista de una lista L es


% sin_elem(+L,?E, ?LSinE) LSinE es la lista L sin una ocurrencia de la lista L.
sin_elem([H|T], H, T). % Si encuentro la ocurrencia en la cabeza la saco.
sin_elem([H|T], X, [H|L]) :- sin_elem(T, X, L). % Si no encuentro E en la cabeza, busco en la cola.



%rotacion(+L, ?R) La lista R es una rotacion de la lista L.
rotacion([H|T],X):-append(B,A,[H|T]),append(A,B,X), B\=[]. % Coloco la cabeza en el final de la lista.



%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------
%   (2) Resolución de un puzle
%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------


%FUNCIONES AUXILIARES

% distinto(?A,?B). -> Verifica que sean distintos, en este caso: cabeza y otro cola.
distinto(co,ca).
distinto(ca,co).

%es_rotacion(+L, ?X) -> La lista X es una rotacion de la lista L. Es como la funcion rotacion de la parte 1, sirve para ver si una pieza es rotacion de otra.
es_rotacion(L,X):-append(B,A,L), append(A,B,X), A\=[].

%sin_elem(+L, ?E, ?LSinE) -> LSinE es la lista L sin una ocurrencia del elemento E. Este predicado sirve para asignar las piezas a la solucion correspondiente para despues hacerle la rotacion adecuada, si es necesario.
sin_elem([H|T], H, T).
sin_elem([H|T], X, [H|L]) :- sin_elem(T, X, L).

%FUNCION PRINCIPAL
%puzle(+Piezas, ?Sol) -> Sol es la solucion al puzzle especificado por Piezas.
puzle([
[lado(P1L1A,P1L1B), lado(P1L2A,P1L2B), lado(P1L3A,P1L3B), lado(P1L4A,P1L4B)],
[lado(P2L1A,P2L1B), lado(P2L2A,P2L2B), lado(P2L3A,P2L3B), lado(P2L4A,P2L4B)],
[lado(P3L1A,P3L1B), lado(P3L2A,P3L2B), lado(P3L3A,P3L3B), lado(P3L4A,P3L4B)],
[lado(P4L1A,P4L1B), lado(P4L2A,P4L2B), lado(P4L3A,P4L3B), lado(P4L4A,P4L4B)],
[lado(P5L1A,P5L1B), lado(P5L2A,P5L2B), lado(P5L3A,P5L3B), lado(P5L4A,P5L4B)],
[lado(P6L1A,P6L1B), lado(P6L2A,P6L2B), lado(P6L3A,P6L3B), lado(P6L4A,P6L4B)],
[lado(P7L1A,P7L1B), lado(P7L2A,P7L2B), lado(P7L3A,P7L3B), lado(P7L4A,P7L4B)],
[lado(P8L1A,P8L1B), lado(P8L2A,P8L2B), lado(P8L3A,P8L3B), lado(P8L4A,P8L4B)],
[lado(P9L1A,P9L1B), lado(P9L2A,P9L2B), lado(P9L3A,P9L3B), lado(P9L4A,P9L4B)]
],
[
[lado(SP1L1A,SP1L1B), lado(SP1L2A,SP1L2B), lado(A1,A), lado(B1,B)],
[lado(A2,A), lado(SP2L2A,SP2L2B), lado(C1,C), lado(D1,D)],
[lado(C2,C), lado(SP3L2A,SP3L2B), lado(SP3L3A,SP3L3B), lado(E1,E)],
[lado(SP4L1A,SP4L1B), lado(B2,B), lado(F1,F), lado(G1,G)],
[lado(F2,F), lado(D2,D), lado(H1,H), lado(I1,I)],
[lado(H2,H), lado(E2,E), lado(SP6L3A,SP6L3B), lado(J1,J)],
[lado(SP7L1A,SP7L1B), lado(G2,G), lado(K1,K), lado(SP7L4A,SP7L4B)],
[lado(K2,K), lado(I2,I), lado(L1,L), lado(SP8L4A,SP8L4B)],
[lado(L2,L), lado(J2,J), lado(SP9L3A,SP9L3B), lado(SP9L4A,SP9L4B)]
]) :-

sin_elem([[lado(P1L1A,P1L1B), lado(P1L2A,P1L2B), lado(P1L3A,P1L3B), lado(P1L4A,P1L4B)], [lado(P2L1A,P2L1B), lado(P2L2A,P2L2B), lado(P2L3A,P2L3B), lado(P2L4A,P2L4B)], [lado(P3L1A,P3L1B), lado(P3L2A,P3L2B), lado(P3L3A,P3L3B), lado(P3L4A,P3L4B)], [lado(P4L1A,P4L1B), lado(P4L2A,P4L2B), lado(P4L3A,P4L3B), lado(P4L4A,P4L4B)], [lado(P5L1A,P5L1B), lado(P5L2A,P5L2B), lado(P5L3A,P5L3B), lado(P5L4A,P5L4B)], [lado(P6L1A,P6L1B), lado(P6L2A,P6L2B), lado(P6L3A,P6L3B), lado(P6L4A,P6L4B)], [lado(P7L1A,P7L1B), lado(P7L2A,P7L2B), lado(P7L3A,P7L3B), lado(P7L4A,P7L4B)], [lado(P8L1A,P8L1B), lado(P8L2A,P8L2B), lado(P8L3A,P8L3B), lado(P8L4A,P8L4B)], [lado(P9L1A,P9L1B), lado(P9L2A,P9L2B), lado(P9L3A,P9L3B), lado(P9L4A,P9L4B)]],P1,ListaSinP1),
sin_elem(ListaSinP1,P2,ListaSinP1P2),
sin_elem(ListaSinP1P2,P3,ListaSinP1P2P3),
sin_elem(ListaSinP1P2P3,P4,ListaSinP1P2P3P4),
sin_elem(ListaSinP1P2P3P4,P5,ListaSinP1P2P3P4P5),
sin_elem(ListaSinP1P2P3P4P5,P6,ListaSinP1P2P3P4P5P6),
sin_elem(ListaSinP1P2P3P4P5P6,P7,ListaSinP1P2P3P4P5P6P7),
sin_elem(ListaSinP1P2P3P4P5P6P7,P8,ListaSinP1P2P3P4P5P6P7P8),
sin_elem(ListaSinP1P2P3P4P5P6P7P8,P9,[]),

es_rotacion(P1,[lado(SP1L1A,SP1L1B), lado(SP1L2A,SP1L2B), lado(A1,A), lado(B1,B)]),
es_rotacion(P2,[lado(A2,A), lado(SP2L2A,SP2L2B), lado(C1,C), lado(D1,D)]),
es_rotacion(P3,[lado(C2,C), lado(SP3L2A,SP3L2B), lado(SP3L3A,SP3L3B), lado(E1,E)]),
es_rotacion(P4,[lado(SP4L1A,SP4L1B), lado(B2,B), lado(F1,F), lado(G1,G)]),
es_rotacion(P5,[lado(F2,F), lado(D2,D), lado(H1,H), lado(I1,I)]),
es_rotacion(P6,[lado(H2,H), lado(E2,E), lado(SP6L3A,SP6L3B), lado(J1,J)]),
es_rotacion(P7,[lado(SP7L1A,SP7L1B), lado(G2,G), lado(K1,K), lado(SP7L4A,SP7L4B)]),
es_rotacion(P8,[lado(K2,K), lado(I2,I), lado(L1,L), lado(SP8L4A,SP8L4B)]),
es_rotacion(P9,[lado(L2,L), lado(J2,J), lado(SP9L3A,SP9L3B), lado(SP9L4A,SP9L4B)]),

distinto(A1, A2),
distinto(B1, B2),
distinto(C1,C2),
distinto(D1,D2),
distinto(E1,E2),
distinto(F1,F2),
distinto(G1,G2),
distinto(H1,H2),
distinto(J1,J2),
distinto(K1,K2),
distinto(L1,L2),
distinto(I1,I2).


%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------
%   (3) Predicados sobre matrices
%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------

% matriz(+M,+N,+E,?A) <- A es una matriz de M filas y N columnas. Cada celda debe tener el valor E.
matriz(_,0,_,[[]]). % Matriz con 0 columnas es vacio.
matriz(M,N,E,A) :- generarMatriz(0,M,N,E,A).
generarMatriz(X,X,_,_,[]).
generarMatriz(Ac,X,N,E,[Y|Ys]) :- generarFila(0,N,Y,E), Ac1 is Ac+1 , generarMatriz(Ac1,X,N,E,Ys). % Utilizado para ir generando las distintas filas
generarFila(X,X,[],_).
generarFila(Ac,X,[E|F],E) :- Ac1 is Ac +1 , generarFila(Ac1,X,F,E). %Genera una fila de la matriz con el valor E.


% valor_celda(+I, +J, +A, ?E)
rowN([H|_],1,H).
rowN([_|T],I,X) :-I1 is I-1, rowN(T,I1,X). % Si no es la fila buscada sigo con otra fila.
findR([H|T],1,H). % Si encuentro la posicion devuelvo la cabeza de la lista.
findR([H|T],N,X) :- N1 is N-1, findR(T,N1,X). % Si no es la posicion buscada sigo buscando en la cola.
valor_celda(I,J,A,E) :- rowN(A,I,F), findR(F, J, E). %Busco la fila y despues el elemento dentro de la fila.


%nuevo_valor_celda(+I, +J, +A1, +E, -A2)
nuevo_valor_col(X,X,[_|Ms],Val,[Val|Ms]).
nuevo_valor_col(Ac,X,[M|Ms],Val,[M|Rs]) :- Ac1 is Ac+1, nuevo_valor_col(Ac1,X,Ms,Val,Rs).
nuevo_valor_fil(X,X,J,[M|Ms],Val,[R|Ms]) :- nuevo_valor_col(1,J,M,Val,R).
nuevo_valor_fil(Ac,X,J,[M|Ms],Val,[M|R]) :- Ac1 is Ac+1 , nuevo_valor_fil(Ac1,X,J,Ms,Val,R).
nuevo_valor_celda(I,J,M1,Val,M2) :- nuevo_valor_fil(1,I,J,M1,Val,M2).


%columna(+M,+N,+A,+J,?C)
columna(M,N,A,J,C):- column(A,J,C).
column([],_,[]).
column([H|T], I, [R|X]):-rowN(H, I, R),column(T,I,X). %Agarra cada fila y saca el elemento buscado.


%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------
%   (4) Predicados eficientes sobre matrices
%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------


% matriz_f(+M,+N,+E,?A) <- A es una matriz de M filas y N columnas. Cada celda debe tener el valor E.
matriz_f(M,N,E,A) :- matriz_f_ac(1,M,N,E,A).
% matriz_f_ac(+Ac,+M,+N,+E,?A) <- A es una matriz de M filas e N columnas. Cada celda debe tener el valor E.
matriz_f_ac(M,M,N,E,A) :- functor(A,matrix,M), generarFila_f(1,N,E,Y), arg(M,A,Y).
matriz_f_ac(Ac,M,N,E,A) :- functor(A,matrix,M),generarFila_f(1,N,E,Y), arg(Ac,A,Y),Ac1 is Ac+1, matriz_f_ac(Ac1,M,N,E,A).
% generarFila_f(+Ac,+N,+E,?Row) <-Row es la fila de largo X y valor E en sus argumentos.
generarFila_f(X,X,E,Row) :- functor(Row,row,X), arg(X,Row,E).
generarFila_f(Ac,X,E,Row) :-functor(Row,row,X), arg(Ac,Row,E), Ac1 is Ac+1, generarFila_f(Ac1,X,E,Row).


%valor_celda_f(+I,+J,+A,?E) ← E es el contenido de la celda (M,N) de la matriz A. A está representada con el formato definido para matriz_f.
valor_celda_f(I, J, M, E) :- arg(I, M, F), arg(J, F, E). %Agarro la fila y luego el elemento dentro de la fila.


%nuevo_valor_celda_f(+M,+N,+A,+E) ← Cambia el contenido de la celda (M,N) de la matriz A por el valor E. A está representada en el formato definido para matriz_f.
nuevo_valor_celda_f(M, N, A, E) :-arg(M, A, F),setarg(N, F, E). %Agaro la fila y luego seteo el elemento.


%columna_f(+M,+N,+A,+J,?C) ← C es la J-ésima columna de la matriz A, de tamaño MxN. C se representa con el functor 'col', con M argumentos. A está representada en el formato definido para matriz_f.
columna_f(M, N, A, J, C) :- J<N+1, A=..[_|L], functor(C, col, M), columna_ff(0,M,L,J,C).  %Si la columna buscada es valida comienzo la busqueda
columna_ff(M,M,[],J,C).
columna_ff(M1, M, [H|T],J,C):-M1<M, M2 is M1+1, arg(J,H,Arg), arg(M2,C,Arg), columna_ff(M2,M,T,J,C). %Voy moviendome en cada fila hasta el nro de columna buscado y la agrego



%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------
%   (5) Predicados para pruebas de eficiencia
%---------------------------------------------------------------------------------------------------------
%---------------------------------------------------------------------------------------------------------


% crearMatrizTT_f(+T,-M) <- M es una matriz TxT donde cada celda (I,J) contiene el valor (I+J)

crearMatrizTT_f(M,N,M2) :- matriz(M,N,0,A), rellenarMatriz(1,1,M,N,A,M2).

% rellenarMatriz_f(+I,+J,M,N,A) <- I,J son acumuladores que representan la celda actual, T es el tamaño de la matriz, M es la matriz
%								   que resulta de reempplazar los elementos (a,b) por el valor a+b.

rellenarMatriz(I, J, M, N, M1, M4) :- I<M, J<N+1, X is I+J, nuevo_valor_celda(I, J, M1, X, M2), II is I+1, JJ is J+1, rellenarMatriz_f(I, JJ, M, N, M2, M3), rellenarMatriz(II, J, M, N, M3, M4).
rellenarMatriz(M, J, M, N, M1, M3):- J<N, X is M+J, nuevo_valor_celda(M, J, M1, X, M2), JJ is J+1, rellenarMatriz_f(M, JJ, M, N, M2, M3).
rellenarMatriz(M, N, M, N, M1, M2):- X is M+N, nuevo_valor_celda(M, N, M1, X, M2).

rellenarMatriz_f(I, J, M, N, M1, M3) :- J<N, X is I+J, nuevo_valor_celda(I, J, M2, X, M3), JJ is J+1, rellenarMatriz_f(I, JJ, M, N, M1, M2).
rellenarMatriz_f(I, N, M, N, M1, M2) :- X is I+N, nuevo_valor_celda(I, N, M1, X, M2).

%---------------------------------------------------------------------------------------------------------

% crearMatrizTT_f2(+T,-M) <- M es una matriz TxT donde cada celda (I,J) contiene el valor (I+J)

crearMatrizTT_f2(M,N,A) :- matriz_f(M,N,0,A), rellenarMatriz_f2(1,1,M,N,A).

% rellenarMatriz_f2(+I,+J,M,N,A) <- I,J son acumuladores que representan la celda actual, T es el tamaño de la matriz, M es la matriz
%								   que resulta de reempplazar los elementos (a,b) por el valor a+b.

rellenarMatriz_f2(I,J,M,N,A):- I>M.
rellenarMatriz_f2(I,J,M,N,A):- J>N, W is I+1, rellenarMatriz_f2(W,1,M,N,A).
rellenarMatriz_f2(I,J,M,N,A) :- J<N+1,Y is I+J, nuevo_valor_celda(I,J,A,Y), X is J+1, rellenarMatriz_f2(I,X,M,N,A).